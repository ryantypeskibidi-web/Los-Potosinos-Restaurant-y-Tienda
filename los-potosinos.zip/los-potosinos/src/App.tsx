import { useState } from 'react'

function App() {
  const [activeSection, setActiveSection] = useState('home')
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const menuItems = [
    { name: 'Burrito Jalisco', description: 'Large flour tortilla stuffed with seasoned beef, rice, beans, lettuce, tomatoes, sour cream, and cheese', price: '$12.99' },
    { name: 'Entomatadas with Steak', description: 'Corn tortillas filled with tender steak, topped with fresh tomato sauce, onions, and queso fresco', price: '$14.99' },
    { name: 'Chimichanga', description: 'Crispy fried burrito filled with your choice of meat, served with guacamole, sour cream, and salsa', price: '$11.99' },
    { name: 'Tacos al Pastor', description: 'Traditional pork tacos marinated in achiote and pineapple, served with cilantro and onions', price: '$10.99' },
    { name: 'Quesadillas', description: 'Grilled flour tortilla filled with melted cheese and your choice of chicken, beef, or vegetables', price: '$9.99' },
    { name: 'Enchiladas', description: 'Three corn tortillas rolled with your choice of filling, topped with red or green sauce and cheese', price: '$11.99' },
    { name: 'Tamales', description: 'Traditional corn dough filled with seasoned pork, wrapped in corn husks', price: '$8.99' },
    { name: 'Carne Asada', description: 'Grilled marinated steak served with rice, beans, guacamole, and warm tortillas', price: '$15.99' },
    { name: 'Pollo en Crema', description: 'Chicken in a rich cream sauce with mushrooms, served with rice and tortillas', price: '$13.99' },
    { name: 'Aqua Fresca', description: 'Refreshing traditional Mexican beverages: Horchata, Jamaica, or Tamarindo', price: '$3.99' },
    { name: 'Flan', description: 'Classic Mexican custard caramel', price: '$5.99' },
    { name: 'Churros', description: 'Fried dough sticks dusted with cinnamon sugar, served with chocolate sauce', price: '$6.99' },
  ]

  const reviews = [
    {
      name: 'Terry Johnson',
      rating: 5,
      date: 'a year ago',
      text: 'Friendly, clean, delicious food, real plates and silverware as well as table service. Will definitely come back.'
    },
    {
      name: 'Amber (Acorn Gates)',
      rating: 5,
      date: '3 years ago',
      text: 'This is an AMAZING hidden gem! The chimichanga is the best thing my husband has eaten in years. We were served very generous portions and the aqua fresca was absolutely delicious. Amazing service and extremely helpful staff.'
    },
    {
      name: 'Christine Hicks',
      rating: 4,
      date: '6 years ago',
      text: 'First time visiting. It was a Friday afternoon so the restaurant was not too crowded. They were pretty quick in seating us, taking our order and bringing our food. The food was good and reasonably priced.'
    }
  ]

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId)
    setMobileMenuOpen(false)
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-stone-900 text-white z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-red-700 flex items-center justify-center">
              <span className="text-2xl">🌮</span>
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-wide" style={{ fontFamily: 'Cinzel, serif' }}>Los Potosinos</h1>
              <p className="text-xs text-stone-400">Restaurant y Tienda</p>
            </div>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {['home', 'menu', 'reviews', 'location'].map((section) => (
              <button
                key={section}
                onClick={() => scrollToSection(section)}
                className={`text-sm font-medium uppercase tracking-wider transition-colors hover:text-red-400 ${activeSection === section ? 'text-red-400' : 'text-stone-300'}`}
              >
                {section === 'home' ? 'Home' : section.charAt(0).toUpperCase() + section.slice(1)}
              </button>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {mobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-stone-800 px-4 py-4 space-y-4">
            {['home', 'menu', 'reviews', 'location'].map((section) => (
              <button
                key={section}
                onClick={() => scrollToSection(section)}
                className="block w-full text-left py-2 text-stone-300 hover:text-red-400"
              >
                {section === 'home' ? 'Home' : section.charAt(0).toUpperCase() + section.slice(1)}
              </button>
            ))}
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="pt-20 min-h-screen bg-gradient-to-br from-stone-900 via-stone-800 to-red-900 flex items-center">
        <div className="max-w-7xl mx-auto px-4 py-20 grid md:grid-cols-2 gap-12 items-center">
          <div className="text-white space-y-6">
            <div className="inline-block px-4 py-2 bg-red-700 rounded-full text-sm font-semibold">
              ⭐ 4.2 Rating · 218 Reviews
            </div>
            <h2 className="text-4xl md:text-6xl font-bold leading-tight" style={{ fontFamily: 'Cinzel, serif' }}>
              Authentic Mexican Cuisine
            </h2>
            <p className="text-xl text-stone-300 leading-relaxed">
              Experience the rich flavors of traditional Mexican food made with fresh ingredients,
              generous portions, and the warmth of true hospitality.
            </p>
            <div className="flex flex-wrap gap-4 pt-4">
              <a
                href="tel:+18632238115"
                className="px-8 py-4 bg-red-700 hover:bg-red-600 rounded-lg font-semibold transition-colors flex items-center gap-2"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                Call to Order
              </a>
              <a
                href="https://www.google.com/maps/place/Los+Potosinos+Restaurant+y+Tienda"
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-4 border-2 border-white hover:bg-white hover:text-stone-900 rounded-lg font-semibold transition-colors flex items-center gap-2"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                Get Directions
              </a>
            </div>
          </div>

          <div className="relative">
            <div className="bg-gradient-to-br from-red-700 to-red-900 rounded-2xl p-8 shadow-2xl">
              <div className="space-y-4 text-white">
                <div className="flex items-start gap-4">
                  <span className="text-3xl">📍</span>
                  <div>
                    <h3 className="font-bold text-lg">Location</h3>
                    <p className="text-stone-200">19001 US-27, Lake Wales, FL 33853</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <span className="text-3xl">🕐</span>
                  <div>
                    <h3 className="font-bold text-lg">Hours</h3>
                    <p className="text-stone-200">Opens daily at 10:00 AM</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <span className="text-3xl">💰</span>
                  <div>
                    <h3 className="font-bold text-lg">Price Range</h3>
                    <p className="text-stone-200">$10 - $20 per person</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <span className="text-3xl">📞</span>
                  <div>
                    <h3 className="font-bold text-lg">Phone</h3>
                    <p className="text-stone-200">(863) 223-8115</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-8 rounded-xl bg-stone-50 hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-green-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-stone-800 mb-2">Dine In</h3>
              <p className="text-stone-600">Enjoy our authentic Mexican atmosphere with table service</p>
            </div>
            <div className="text-center p-8 rounded-xl bg-stone-50 hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-blue-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-stone-800 mb-2">Take Out</h3>
              <p className="text-stone-600">Quick takeout with fresh, quality packaging</p>
            </div>
            <div className="text-center p-8 rounded-xl bg-stone-50 hover:shadow-lg transition-shadow">
              <div className="w-16 h-16 mx-auto mb-4 bg-orange-100 rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-orange-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-stone-800 mb-2">Delivery</h3>
              <p className="text-stone-600">Hot food delivered to your doorstep</p>
            </div>
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <section id="menu" className="py-20 bg-stone-100">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <span className="text-red-700 font-semibold uppercase tracking-wider text-sm">Our Menu</span>
            <h2 className="text-4xl font-bold text-stone-800 mt-2" style={{ fontFamily: 'Cinzel, serif' }}>Featured Dishes</h2>
            <p className="text-stone-600 mt-4 max-w-2xl mx-auto">
              Made fresh daily with authentic recipes passed down through generations
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {menuItems.map((item, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-shadow group"
              >
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-lg font-bold text-stone-800 group-hover:text-red-700 transition-colors">
                    {item.name}
                  </h3>
                  <span className="text-xl font-bold text-red-700">{item.price}</span>
                </div>
                <p className="text-stone-600 text-sm leading-relaxed">{item.description}</p>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-stone-600 mb-4">Want to see our full menu or order?</p>
            <a
              href="tel:+18632238115"
              className="inline-flex items-center gap-2 px-6 py-3 bg-red-700 hover:bg-red-600 text-white rounded-lg font-semibold transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
              Call to Order: (863) 223-8115
            </a>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section id="reviews" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <span className="text-red-700 font-semibold uppercase tracking-wider text-sm">Testimonials</span>
            <h2 className="text-4xl font-bold text-stone-800 mt-2" style={{ fontFamily: 'Cinzel, serif' }}>What Our Customers Say</h2>
            <div className="flex items-center justify-center gap-2 mt-4">
              <div className="flex text-yellow-400 text-2xl">
                {[1, 2, 3, 4, 5].map((star) => (
                  <span key={star} className={star <= 4 ? 'text-yellow-400' : 'text-stone-300'}>★</span>
                ))}
              </div>
              <span className="text-xl font-bold text-stone-800">4.2</span>
              <span className="text-stone-600">({218} reviews)</span>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {reviews.map((review, index) => (
              <div key={index} className="bg-stone-50 rounded-xl p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 bg-red-700 rounded-full flex items-center justify-center text-white font-bold text-lg">
                    {review.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-800">{review.name}</h4>
                    <p className="text-sm text-stone-500">{review.date}</p>
                  </div>
                </div>
                <div className="flex text-yellow-400 mb-3">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <span key={star} className={star <= review.rating ? 'text-yellow-400' : 'text-stone-300'}>★</span>
                  ))}
                </div>
                <p className="text-stone-600 leading-relaxed">{review.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Location Section */}
      <section id="location" className="py-20 bg-stone-900 text-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-red-400 font-semibold uppercase tracking-wider text-sm">Find Us</span>
              <h2 className="text-4xl font-bold mt-2" style={{ fontFamily: 'Cinzel, serif' }}>Visit Our Restaurant</h2>
              <p className="text-stone-400 mt-4 leading-relaxed">
                Located on US-27 in Lake Wales, Florida, we're easy to find and have ample parking.
                Come experience the authentic taste of Mexico!
              </p>

              <div className="mt-8 space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-red-700 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold">Address</h4>
                    <p className="text-stone-400">19001 US-27, Lake Wales, FL 33853, USA</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-red-700 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold">Phone</h4>
                    <p className="text-stone-400">(863) 223-8115</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-red-700 rounded-full flex items-center justify-center flex-shrink-0">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-bold">Hours</h4>
                    <p className="text-stone-400">Opens daily at 10:00 AM</p>
                  </div>
                </div>
              </div>

              <div className="mt-8 flex flex-wrap gap-4">
                <a
                  href="https://www.google.com/maps/place/Los+Potosinos+Restaurant+y+Tienda"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3 bg-red-700 hover:bg-red-600 rounded-lg font-semibold transition-colors flex items-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                  </svg>
                  Get Directions
                </a>
                <a
                  href="tel:+18632238115"
                  className="px-6 py-3 border-2 border-white hover:bg-white hover:text-stone-900 rounded-lg font-semibold transition-colors flex items-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  Call Now
                </a>
              </div>
            </div>

            <div className="rounded-xl overflow-hidden shadow-2xl">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3511.5!2d-81.6!3d27.9!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjfCsDU0JzAwLjAiTiA4McKwMzYnMDAuMCJX!5e0!3m2!1sen!2sus!4v1"
                width="100%"
                height="400"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Los Potosinos Location"
              ></iframe>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-stone-950 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-red-700 flex items-center justify-center">
              <span className="text-xl">🌮</span>
            </div>
            <h3 className="text-xl font-bold" style={{ fontFamily: 'Cinzel, serif' }}>Los Potosinos</h3>
          </div>
          <p className="text-stone-400 mb-6">Restaurant y Tienda | Authentic Mexican Cuisine</p>
          <p className="text-stone-500 text-sm">© 2025 Los Potosinos Restaurant. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

export default App
